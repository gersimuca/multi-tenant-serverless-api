"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client = lib_dynamodb_1.DynamoDBDocumentClient.from(new client_dynamodb_1.DynamoDBClient({
    endpoint: "http://localhost:4566",
    region: "us-east-1"
}));
const TABLE = process.env.TABLE_NAME;
const handler = async (event) => {
    const tenantId = event.headers["x-tenant-id"];
    if (!tenantId) {
        return { statusCode: 401, body: "Missing tenant id" };
    }
    if (event.httpMethod === "POST") {
        const body = JSON.parse(event.body);
        await client.send(new lib_dynamodb_1.PutCommand({
            TableName: TABLE,
            Item: {
                tenant_id: tenantId,
                item_id: crypto.randomUUID(),
                name: body.name
            }
        }));
        return { statusCode: 201, body: "Item created" };
    }
    if (event.httpMethod === "GET") {
        const result = await client.send(new lib_dynamodb_1.QueryCommand({
            TableName: TABLE,
            KeyConditionExpression: "tenant_id = :t",
            ExpressionAttributeValues: {
                ":t": tenantId
            }
        }));
        return {
            statusCode: 200,
            body: JSON.stringify(result.Items)
        };
    }
    return { statusCode: 405, body: "Method not allowed" };
};
exports.handler = handler;
